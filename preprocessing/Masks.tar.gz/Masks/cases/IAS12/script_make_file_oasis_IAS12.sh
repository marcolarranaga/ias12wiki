#!/bin/bash
functions_path=../../functions/
. ${functions_path}/create_roms_grids_function.sh
. ${functions_path}/create_roms_masks_function.sh
. ${functions_path}/create_roms_corners_function.sh
. ${functions_path}/create_roms_areas_function.sh
. ${functions_path}/create_wrf_grids_function.sh
. ${functions_path}/create_wrf_masks_function.sh
. ${functions_path}/create_wrf_corners_function.sh
. ${functions_path}/create_wrf_areas_function.sh
. ${functions_path}/create_wrf_CPLMASK_function.sh
. ${functions_path}/duplicate_wrf_CPLMASK_function.sh
#
#--------------------
# 0. Path for ROMS/WRF Grid File
#--------------------

roms_grid_file='infiles/mesh_mask_IAS12_mod.nc'
wrf_grid_file='infiles/geo_em.d01.nc'
out_dir='outfiles/'

myconfig='IAS12 Coupled Grids and files'
mydate=`date +%Y%m%d`
#
#--------------------
#1. Grid names
#--------------------
RRN0='rrn0' # Roms Rho Normal    0=Parent
RRP0='rrp0' # Roms Rho Processed 0=Parent
RUN0='run0' # Roms U   Normal    0=Parent
RUP0='rup0' # Roms U   Processed 0=Parent
RVN0='rvn0' # Roms V   Normal    0=Parent
RVP0='rvp0' # Roms V   Processed 0=Parent
#
WRN0='wrn0' # WRF Rho Normal    0=Parent
WRP0='wrp0' # WRF Rho Processed 0=Parent
#
#
#--------------------
# 2. Processing ROMS Grids Parent and Childrens
#--------------------
create_roms_grids_function
#create_roms_corners_function  
create_roms_masks_function
create_roms_areas_function

#create_roms_grids_function 1
#create_roms_corners_function 1 
#create_roms_masks_function 1
#create_roms_areas_function 1

#--------------------
# 3. Processing WRF Grid
#--------------------
create_wrf_grids_function 
create_wrf_masks_function 
create_wrf_corners_function 
create_wrf_areas_function 
create_wrf_CPLMASK_function
duplicate_wrf_CPLMASK_function

#create_wrf_grids_function 1
#create_wrf_masks_function 1
#create_wrf_corners_function 1
#create_wrf_areas_function 1
#create_wrf_CPLMASK_function 1
#duplicate_wrf_CPLMASK_function 1

#--------------------
# 4. Merging in the file grids.nc
#--------------------
echo Merging Grids and Corners
mv -f grids_roms.nc grids.nc
ncks -A grids_wrf.nc grids.nc
[ -f grids_roms.nc.1 ] && ncks -A grids_roms.nc.1 grids.nc
[ -f grids_wrf.nc.1 ] && ncks -A grids_wrf.nc.1 grids.nc
[ -f corners_roms.nc ] && ncks -A corners_roms.nc grids.nc
[ -f corners_wrf.nc ] && ncks -A corners_wrf.nc grids.nc
[ -f corners_roms.nc.1 ] && ncks -A corners_roms.nc.1 grids.nc
[ -f corners_wrf.nc.1 ] && ncks -A corners_wrf.nc.1 grids.nc
rm -f grids_*.nc* corners*.nc*

echo Merging Masks
mv -f masks_roms.nc masks.nc
ncks -A masks_wrf.nc masks.nc
[ -f masks_roms.nc.1 ] && ncks -A masks_roms.nc.1 masks.nc
[ -f masks_wrf.nc.1 ] && ncks -A masks_wrf.nc.1 masks.nc
rm -f masks_*.nc*

echo Merging Areas
mv -f areas_roms.nc areas.nc
ncks -A areas_wrf.nc areas.nc
[ -f grids_roms.nc.1 ] && ncks -A areas_roms.nc.1 areas.nc
[ -f grids_wrf.nc.1 ] && ncks -A areas_wrf.nc.1 areas.nc
rm -f areas_*.nc*

# Clean history and global Attributes
ncatted -h -O -a ,global,d,, grids.nc
ncatted -h -a title,global,c,c,"${myconfig}" grids.nc
ncatted -h -a date,global,c,c,${mydate} grids.nc

ncatted -h -O -a ,global,d,, masks.nc
ncatted -h -a title,global,c,c,"${myconfig}" masks.nc
ncatted -h -a date,global,c,c,${mydate} masks.nc

ncatted -h -O -a ,global,d,, areas.nc
ncatted -h -a title,global,c,c,"${myconfig}" areas.nc
ncatted -h -a date,global,c,c,${mydate} areas.nc

echo Moving files
mv -f grids.nc areas.nc masks.nc CPLMASK* ${out_dir}
