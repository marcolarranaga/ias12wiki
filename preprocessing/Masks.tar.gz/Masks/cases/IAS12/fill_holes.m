gridfile = 'outfiles/CPLMASK_d01.nc';

mask=squeeze(ncread(gridfile, 'CPLMASK', [1 1 1 1], [Inf Inf 1 1]));
[ny,nx] = size(mask);

reg = bwlabel(mask,4);


lint =  0; %% size of largest region
lreg = 0; %% number of largest region
nreg = max(max(reg)); %% number of regions
for i = 1:max(max(reg))
  int = sum(sum(reg==i));
  if int>lint
    lreg = i;
    lint = int;
  end
end


mask(reg~=lreg) = 0;
ncwrite(gridfile, 'CPLMASK', mask);

%%%%

gridfile = 'outfiles/masks.nc';


mask = -ncread(gridfile, 'wrp0.msk')+1;
[ny,nx] = size(mask);


reg = bwlabel(mask,4);

lint =  0; %% size of largest region
lreg = 0; %% number of largest region
nreg = max(max(reg)); %% number of regions
for i = 1:max(max(reg))
  int = sum(sum(reg==i));
  if int>lint
    lreg = i;
    lint = int;
  end
end


mask(reg~=lreg) = 0;
ncwrite(gridfile, 'wrp0.msk', -mask+1)
ncwrite(gridfile, 'wrn0.msk', -mask+1)

varname=['r';'u';'v'];
for j=1:length(varname)
	msk=ncread(gridfile,['r' varname(j) 'n0.msk']);
	ncwrite(gridfile,['r' varname(j) 'p0.msk'], msk)
end


