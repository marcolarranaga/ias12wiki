clear all; close all;

% Read coordinates
filename='infiles/mesh_mask_IAS12_mod.nc';

varlist={'lon_rho';'lon_u';'lon_v';'lat_rho';'lat_u';'lat_v'};
for j=1:length(varlist)

    evalc([ varlist{j} '=ncread(''' filename ''',''' varlist{j} ''')''']);

end

[ny,nx]=size(lon_rho);

% Calculate conrners
varlist={'rho';'u';'v'};
varname=['r';'u';'v'];
signlon=['+';'-';'-';'+'];
signlat=['+';'+';'-';'-'];
for j=1:length(varname)

	evalc(['r' varname(j) 'n0_clo=ones(ny,nx,4)*NaN']);
	evalc(['r' varname(j) 'n0_cla=ones(ny,nx,4)*NaN']);

	deltalon=eval(['(lon_' varlist{j} '(:,2:end) - lon_' varlist{j} '(:,1:end-1))/2']);
	deltalat=eval(['(lat_' varlist{j} '(2:end,:) - lat_' varlist{j} '(1:end-1,:))/2']);

	for k=1:4

		evalc(['r' varname(j) 'n0_clo(:,2:end,k)=lon_' varlist{j} '(:,2:end)' signlon(k) 'deltalon']);
		evalc(['r' varname(j) 'n0_cla(2:end,:,k)=lat_' varlist{j} '(2:end,:)' signlat(k) 'deltalat']);

		evalc(['r' varname(j) 'n0_clo(:,1,k)=lon_' varlist{j} '(:,1)' signlon(k) 'deltalon(:,1)']);
		evalc(['r' varname(j) 'n0_cla(1,:,k)=lat_' varlist{j} '(1,:)' signlat(k) 'deltalat(1,:)']);

	end

	evalc(['r' varname(j) 'n0_clo=permute(r' varname(j) 'n0_clo,[2 1 3])']);
	evalc(['r' varname(j) 'n0_cla=permute(r' varname(j) 'n0_cla,[2 1 3])']);

	evalc(['r' varname(j) 'p0_clo=r' varname(j) 'n0_clo']);
	evalc(['r' varname(j) 'p0_cla=r' varname(j) 'n0_cla']);

	evalc(['x_r' varname(j) 'n0=lon_' varlist{j} '(1,:)']);
	evalc(['y_r' varname(j) 'n0=lat_' varlist{j} '(:,1)']);

end

varlist={'lon_rho';'lon_u';'lon_v';'lat_rho';'lat_u';'lat_v'};
for j=1:length(varlist)

	evalc([ varlist{j} '=' varlist{j} '''']);

end

[ny,nx]=size(lon_rho);

%%% Gen netcdf {{{
varlist={'RHO';'U';'V'};
varname={'r';'u';'v'};
varnameclass={'n';'p'};
coordxy={'x';'y'};
coordlist={'longitude','latitude'};
coordlist2={'o';'a'};
coordlist3={'Longitudes';'Latitudes'};
unitslist={'degree_east','degree_north'};

clear ncdimlist ncdimsize ncglobatt ncvarlist

% Build ncdimlist and ncdimsize
cont=1;
for j=1:length(varname)

	for k=1:2

		ncdimlist{cont,1}=[ coordxy{k} '_r' varname{j} 'n01' ];
		ncdimsize(cont,1)=eval(['n' coordxy{k} ]);
		cont=cont+1;
	end

end

ncdimlist{cont,1}='corners';
ncdimsize(cont,1)=4;

% Build ncvarlist
cont=1;
for j=1:3

	for k=2:-1:1

		ncvarlist{cont}={[ coordxy{k} '_r' varname{j} 'n0'],{[ coordxy{k} '_r' varname{j} 'n01']},...
			'long_name',[ coordlist{k} ' of ' varlist{j} '-points'],'units',unitslist{k}};

		cont=1;

	end

end

for j=1:length(varname)

	for k=1:length(varnameclass)

		for l=1:length(coordlist2)

			ncvarlist{cont}={['r' varname{j} varnameclass{k} '0_cl' coordlist2{l} ],...
				{['y_r' varname{j} 'n01' ],['x_r' varname{j} 'n01' ],'corners'},...
				'long_name',[ coordlist3{l} ' of r' varname{j} 'n0 corners'],'units',unitslist{l}};

			cont=cont+1;

		end

	end

end

ncname='corners_roms_tmp.nc';

gen_netcdf
%%%}}}

%%%% Rename dimensions and variables with NCO %%%{{{
for j=1:length(varname)

	for k=1:length(varnameclass)

		for l=1:length(coordlist2)

			evalc(['!ncrename -v r' varname{j} varnameclass{k} '0_cl' coordlist2{l} ',r' varname{j} varnameclass{k} '0.cl' coordlist2{l} ' ' ncname ]);

		end

	end

end
%
%for j=1:length(varname)
%
%	evalc(['!ncrename -d x_r' varname{j} 'n01,y_r' varname{j} 'n0 ' ncname ]);
%	evalc(['!ncrename -d y_r' varname{j} 'n01,x_r' varname{j} 'n0 ' ncname ]);
%
%end
%
%%}}}

!python3 rename_dimensions.py

