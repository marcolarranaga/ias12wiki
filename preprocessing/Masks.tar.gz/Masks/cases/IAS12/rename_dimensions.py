import netCDF4 as nc
import numpy as np
import os

ncfile=nc.Dataset('corners_roms_tmp.nc')

ny=ncfile.dimensions['x_rrn01'].size
nx=ncfile.dimensions['y_rrn01'].size

varname=['r','u','v']
varnameclass=['n','p']
coordname=['o','a']

data={}

for j in range(len(varname)):

    for k in range(len(varnameclass)):

        data[f'r{varname[j]}{varnameclass[k]}0.clo']=np.ones((4,ny,nx))*np.NaN
        data[f'r{varname[j]}{varnameclass[k]}0.cla']=np.ones((4,ny,nx))*np.NaN


        data[f'r{varname[j]}{varnameclass[k]}0.clo']=\
            ncfile.variables[f'r{varname[j]}{varnameclass[k]}0.clo'][:].data

        data[f'r{varname[j]}{varnameclass[k]}0.cla']=\
            ncfile.variables[f'r{varname[j]}{varnameclass[k]}0.cla'][:].data


ncname='corners_roms.nc'

if os.path.exists(ncname):
    os.remove(ncname)

ncout=nc.Dataset('corners_roms.nc','w',format='NETCDF4')

for j in range(len(varname)):

    ncout.createDimension(f'x_r{varname[j]}n0',nx)
    ncout.createDimension(f'y_r{varname[j]}n0',ny)

ncout.createDimension('corners',4)

ncout.close()


for j in range(len(varname)):

    for k in range(len(varnameclass)):

        for l in range(len(coordname)):

            ncout=nc.Dataset(ncname,'a')

            ncvar=ncout.createVariable(f'r{varname[j]}{varnameclass[k]}0.cl{coordname[l]}','f',
                ('corners',f'y_r{varname[j]}n0',f'x_r{varname[j]}n0'))
            ncvar[:]=data[f'r{varname[j]}{varnameclass[k]}0.cl{coordname[l]}']

            ncout.close()


os.system('rm corners_roms_tmp.nc')

