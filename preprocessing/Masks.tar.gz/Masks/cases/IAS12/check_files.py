import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np

# Get data{{{
model=['r','n']

nmodel=0
varname=['r','u','v']

ncfilegrid=nc.Dataset('grids_roms.nc')
dirgrid={}
for j in range(0,len(varname)):

    dirgrid[f'{model[nmodel]}{varname[j]}n0_lon']=ncfilegrid.variables[f'{model[nmodel]}{varname[j]}n0.lon'][:]
    dirgrid[f'{model[nmodel]}{varname[j]}n0_lat']=ncfilegrid.variables[f'{model[nmodel]}{varname[j]}n0.lat'][:]


ncfilecorners=nc.Dataset('corners_roms.nc')
dircorners={}
for j in range(0,len(varname)):

    dircorners[f'{model[nmodel]}{varname[j]}n0_lon']=ncfilecorners.variables[f'{model[nmodel]}{varname[j]}n0.clo'][:]
    dircorners[f'{model[nmodel]}{varname[j]}n0_lat']=ncfilecorners.variables[f'{model[nmodel]}{varname[j]}n0.cla'][:]
#}}}

ylim=[31.6, 31.9]
xlim=[-98.2, -97.9]

# Figures{{{
clors=['k','b','r']
fig,ax=plt.subplots()
for j in range(0,len(varname)):

    ax.plot(dirgrid[f'{model[nmodel]}{varname[j]}n0_lon'],dirgrid[f'{model[nmodel]}{varname[j]}n0_lat'],f'o{clors[j]}',markersize=10,markerfacecolor='none')

ax.set_ylim(ylim)
ax.set_xlim(xlim)

#fig.show()

marker=['^','v','<','>']
clors=['k','b','r']
for j in range(0,len(marker)):
    for k in range(0,len(varname)):

        ax.plot(dircorners[f'{model[nmodel]}{varname[k]}n0_lon'][j,:,:],dircorners[f'{model[nmodel]}{varname[k]}n0_lat'][j,:,:],f'{marker[j]}{clors[k]}')

ax.axis('equal')
ax.set_ylim(ylim)
ax.set_xlim(xlim)

fig.show()
#}}}


