ncks -A -v x_rrn0,x_run0,x_rvn0,y_rrn0,y_run0,y_rvn0,x_wrn0,y_wrn0 areas.nc -o areas_ok.nc
ncks -A -v x_rrn0,y_rrn0,x_run0,y_run0,x_rvn0,y_rvn0,x_wrn0,y_wrn0 grids.nc -o grids_ok.nc
ncks -A -v x_rrn0,y_rrn0,x_run0,y_run0,x_rvn0,y_rvn0,x_wrn0,y_wrn0 masks.nc -o masks_ok.nc
mv -f areas_ok.nc areas.nc
mv -f grids_ok.nc grids.nc
mv -f masks_ok.nc masks.nc
