clear all; close all;

title = 'mesh_mask_IAS12';

infilename='infiles/mesh_mask_IAS12.nc';
outfilename='infiles/mesh_mask_IAS12_mod.nc';

lon_rho=ncread(infilename,'nav_lon')';
lat_rho=ncread(infilename,'nav_lat')';

% Generate u and v grids
lon_v=lon_rho;
delta=(lat_rho(2:end,:)-lat_rho(1:end-1,:))/2;

lat_v=lat_rho*NaN;
lat_v(1:end-1,:)=lat_rho(1:end-1,:) + delta;
lat_v(end,:)=lat_rho(end,:)+delta(end,:);

lat_u=lat_rho;
delta=(lon_rho(:,2:end)-lon_rho(:,1:end-1))/2;

lon_u=lon_rho*NaN;
lon_u(:,1:end-1)=lon_rho(:,1:end-1) + delta;
lon_u(:,end)=lon_rho(:,end) + delta(:,end);

% transpose variables
varlist={'lon_rho';'lon_u';'lon_v';'lat_rho';'lat_u';'lat_v'};
for j=1:length(varlist)

	evalc([ varlist{j} '=' varlist{j} '''']);

end

% Reading mask variables
varlist={'tmask';'umask';'vmask'};
varlistr={'mask_rho';'mask_u';'mask_v'};

for j=1:length(varlist)

	evalc([ varlistr{j} '=ncread(''' infilename ''',''' varlist{j} ''',[1 1 1 1],[inf inf 1 1])']');

end

[nx,ny]=size(lon_rho);

% Gen netcdf{{{
clear ncdimlist ncdimsize ncglobatt ncvarlist
ncdimlist={'xi_u';'eta_u';'xi_v';'eta_v';'xi_rho';'eta_rho'};
ncdimsize=[nx;ny;nx;ny;nx;ny];

ncvarlist{1}={'lon_rho',{'xi_rho', 'eta_rho'},'long_name','longitude of RHO-points','units','degree_east'};
ncvarlist{2}={'lon_u',{'xi_u', 'eta_u'},'long_name','longitude of U-points','units','degree_east'};
ncvarlist{3}={'lon_v',{'xi_v', 'eta_v'},'long_name','longitude of V-points','units','degree_east'};

ncvarlist{4}={'lat_rho',{'xi_rho', 'eta_rho'},'long_name','latitude of RHO-points','units','degree_north'};
ncvarlist{5}={'lat_u',{'xi_u', 'eta_u'},'long_name','latitude of U-points','units','degree_north'};
ncvarlist{6}={'lat_v',{'xi_v', 'eta_v'},'long_name','latitude of V-points','units','degree_north'};

ncvarlist{7}={'mask_rho',{'xi_rho', 'eta_rho'},'long_name','mask on RHO-points','option_0','land','option_1','water'};
ncvarlist{8}={'mask_u',{'xi_u', 'eta_u'},'long_name','mask on U-points','option_0','land','option_1','water'};
ncvarlist{9}={'mask_v',{'xi_v', 'eta_v'},'long_name','mask on V-points','option_0','land','option_1','water'};

ncglobatt{1}={'title',title};
ncglobatt{2}={'date',date};
ncglobatt{3}={'type','ROMS grid file'};

ncname=outfilename;

gen_netcdf
%}}}

